import React from 'react'

function Section() {
  return (
    <div>Section</div>
  )
}

export default Section